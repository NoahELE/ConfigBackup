// ==UserScript==
// @name              anti-redirect
// @author            Axetroy
// @collaborator      Axetroy
// @description       This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @version           2.19.1.2
// @update            2021-07-08 16:16:14
// @grant             GM_xmlhttpRequest
// @include           *www.baidu.com*
// @include           *tieba.baidu.com*
// @include           *v.baidu.com*
// @include           *xueshu.baidu.com*
// @include           *www.google.*
// @include           *docs.google.*
// @include           *mail.google.*
// @include           *play.google.*
// @include           *youtube.com/watch?v=*
// @include           *youtube.com/channel/*
// @include           *encrypted.google.com*
// @include           *www.so.com*
// @include           *www.zhihu.com*
// @include           *daily.zhihu.com*
// @include           *zhuanlan.zhihu.com*
// @include           *weibo.com*
// @include           *twitter.com*
// @include           *www.sogou.com*
// @include           *juejin.im*
// @include           *juejin.cn*
// @include           *mail.qq.com*
// @include           *addons.mozilla.org*
// @include           *www.jianshu.com*
// @include           *www.douban.com*
// @include           *getpocket.com*
// @include           *www.dogedoge.com*
// @include           *51.ruyo.net*
// @include           *steamcommunity.com*
// @include           *mijisou.com*
// @include           *blog.csdn.net*
// @include           *.oschina.net*
// @include           *app.yinxiang.com*
// @connect           www.baidu.com
// @connect           *
// @compatible        chrome  完美运行
// @compatible        firefox  完美运行
// @supportURL        https://axetroy.github.io/
// @run-at            document-start
// @contributionURL   troy450409405@gmail.com|alipay.com
// @namespace         https://greasyfork.org/zh-CN/users/3400-axetroy
// @license           Anti 996 License; https://github.com/axetroy/anti-redirect/blob/master/LICENSE
// ==/UserScript==
